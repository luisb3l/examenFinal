from django.urls import path
from .views import recetas_view

urlpatterns = [
    path('', recetas_view, name='recetas_view'),
]