import requests
from django.shortcuts import render

def recetas_view(request):
    categorias_response = requests.get('https://www.themealdb.com/api/json/v1/1/list.php?c=list')
    categorias = categorias_response.json().get('meals', [])

    categoria_seleccionada = request.GET.get('categoria', 'Seafood')

    recetas_response = requests.get(f'https://www.themealdb.com/api/json/v1/1/filter.php?c={categoria_seleccionada}')
    recetas = recetas_response.json().get('meals', [])

    receta_random_response = requests.get('https://www.themealdb.com/api/json/v1/1/random.php')
    receta_random = receta_random_response.json().get('meals', [])[0] if receta_random_response.json().get('meals') else None

    return render(request, 'recetas/receta.html', {
        'categorias': categorias,
        'recetas': recetas,
        'receta_random': receta_random,
        'categoria_seleccionada': categoria_seleccionada,
    })
